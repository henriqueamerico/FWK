<html>
    <head>
        <title>Fazer Cadastro</title>

        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">

        <style>
            .brand-dropdown:hover .dropdown-menu {
                display: block;
                margin-top: 0;
            }
        </style>
    </head>

    <body>

        <div class="dropdown brand-dropdown">
            <a class="navbar-brand dropdown-toggle" 
               href="#" 
               role="button" 
               data-bs-toggle="dropdown" 
               aria-expanded="false">
                Cadastros
            </a>

            <ul class="dropdown-menu">
                
            <li>
                <a class="dropdown-item" 
                   href="#"
                   onclick="carregarFormulario('view/form_aluno.php'); return false;">
                    aluno
                </a>
            </li>
        
            <li>
                <a class="dropdown-item" 
                   href="#"
                   onclick="carregarFormulario('view/form_curso.php'); return false;">
                    curso
                </a>
            </li>
        
            <li>
                <a class="dropdown-item" 
                   href="#"
                   onclick="carregarFormulario('view/form_professor.php'); return false;">
                    professor
                </a>
            </li>
        
            </ul>
        </div>

        <div id="conteudo" class="container mt-4">
            <h3>Selecione um cadastro</h3>
        </div>

        <script>
            function carregarFormulario(url) {

                fetch(url)
                    .then(response => response.text())
                    .then(html => {
                        document.getElementById("conteudo").innerHTML = html;
                    })
                    .catch(error => {
                        console.error(error);
                    });

            }
        </script>

    </body>
</html>